import './page/sw-product-detail';
import './view/sw-product-detail-base';
