# 1.1.4
- Fix product detail page custom layout bug

# 1.1.3
- Add Cart item type Rule filter

# 1.1.2
- Fix product detail page custom layout bug

# 1.1.1
- Fix PHP8.2 warning

# 1.1.0
- Compatibility with Shopware 6.5

# 1.0.1
- Add Interfaces
- Fix migration bug

# 1.0.0
- Initial release
